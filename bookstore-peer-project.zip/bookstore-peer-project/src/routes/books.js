const express = require('express');
const router = express.Router();
const {
  getAllBooks,
  getBookByISBN,
  getBooksByAuthor,
  getBooksByTitle,
  getBookReviews
} = require('../controllers/books');

// Public endpoints (General users)
router.get('/', getAllBooks);                    // Task 1
router.get('/isbn/:isbn', getBookByISBN);        // Task 2
router.get('/author/:author', getBooksByAuthor); // Task 3
router.get('/title/:title', getBooksByTitle);    // Task 4
router.get('/review/:isbn', getBookReviews);     // Task 5

module.exports = router;
