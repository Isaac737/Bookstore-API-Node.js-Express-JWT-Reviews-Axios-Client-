const express = require('express');
const router = express.Router();
const { upsertReview, deleteOwnReview } = require('../controllers/reviews');
const { authRequired } = require('../middleware/auth');

// Task 8: add/modify review (PUT + JWT)
router.put('/review/:isbn', authRequired, upsertReview);

// Task 9: delete own review (DELETE + JWT)
router.delete('/review/:isbn', authRequired, deleteOwnReview);

module.exports = router;
