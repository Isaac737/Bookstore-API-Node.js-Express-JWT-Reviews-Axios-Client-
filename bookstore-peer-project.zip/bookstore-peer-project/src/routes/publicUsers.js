const express = require('express');
const router = express.Router();
const { register, login } = require('../controllers/users');

router.post('/register', register); // Task 6
router.post('/login', login);       // Task 7

module.exports = router;
