const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');

// Preload some books
const books = [
  {
    isbn: '9780131103627',
    title: 'The C Programming Language',
    author: 'Brian W. Kernighan, Dennis M. Ritchie',
    reviews: [] // { user: 'alice', review: 'Great!' }
  },
  {
    isbn: '9780132350884',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    reviews: []
  },
  {
    isbn: '9781491950296',
    title: 'Designing Data-Intensive Applications',
    author: 'Martin Kleppmann',
    reviews: []
  }
];

// Users: username unique, password hash
const users = [
  // demo user: username: demo, password: password
];

async function seedDemoUser() {
  const exists = users.find(u => u.username === 'demo');
  if (!exists) {
    const hash = await bcrypt.hash('password', 10);
    users.push({ id: uuidv4(), username: 'demo', passwordHash: hash });
  }
}

module.exports = { books, users, seedDemoUser };
