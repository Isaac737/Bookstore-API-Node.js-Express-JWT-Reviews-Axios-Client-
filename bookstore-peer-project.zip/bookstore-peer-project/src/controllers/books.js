const { books } = require('../store');

// Task 1: Get the book list available in the shop
function getAllBooks(req, res, next) {
  res.json({ data: books });
}

// Task 2: Get the books based on ISBN
function getBookByISBN(req, res, next) {
  const isbn = req.params.isbn;
  const book = books.find(b => b.isbn === isbn);
  if (!book) {
    const err = new Error('Book not found');
    err.status = 404;
    return next(err);
  }
  res.json({ data: book });
}

// Task 3: Get all books by Author
function getBooksByAuthor(req, res, next) {
  const author = decodeURIComponent(req.params.author).toLowerCase();
  const result = books.filter(b => b.author.toLowerCase().includes(author));
  res.json({ data: result });
}

// Task 4: Get all books based on Title
function getBooksByTitle(req, res, next) {
  const title = decodeURIComponent(req.params.title).toLowerCase();
  const result = books.filter(b => b.title.toLowerCase().includes(title));
  res.json({ data: result });
}

// Task 5: Get book Review (by ISBN)
function getBookReviews(req, res, next) {
  const isbn = req.params.isbn;
  const book = books.find(b => b.isbn === isbn);
  if (!book) {
    const err = new Error('Book not found');
    err.status = 404;
    return next(err);
  }
  res.json({ data: book.reviews || [] });
}

module.exports = { getAllBooks, getBookByISBN, getBooksByAuthor, getBooksByTitle, getBookReviews };
