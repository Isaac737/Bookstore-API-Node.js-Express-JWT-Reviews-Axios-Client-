const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { users } = require('../store');

// Task 6: Register New user
async function register(req, res, next) {
  const { username, password } = req.body || {};
  if (!username || !password) {
    const err = new Error('username and password required');
    err.status = 400;
    return next(err);
  }
  const exists = users.find(u => u.username === username);
  if (exists) {
    const err = new Error('username already exists');
    err.status = 409;
    return next(err);
  }
  const passwordHash = await bcrypt.hash(password, 10);
  const user = { id: uuidv4(), username, passwordHash };
  users.push(user);
  res.status(201).json({ message: 'registered', user: { id: user.id, username: user.username } });
}

// Task 7: Login user
async function login(req, res, next) {
  const { username, password } = req.body || {};
  if (!username || !password) {
    const err = new Error('username and password required');
    err.status = 400;
    return next(err);
  }
  const user = users.find(u => u.username === username);
  if (!user) {
    const err = new Error('invalid credentials');
    err.status = 401;
    return next(err);
  }
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    const err = new Error('invalid credentials');
    err.status = 401;
    return next(err);
  }
  const token = jwt.sign({ sub: user.id, username: user.username }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '1h' });
  res.json({ message: 'logged in', token });
}

module.exports = { register, login };
