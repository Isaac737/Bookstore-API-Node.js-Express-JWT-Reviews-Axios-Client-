const { books } = require('../store');

// PUT /auth/review/:isbn  (Task 8)
function upsertReview(req, res, next) {
  const { isbn } = req.params;
  const book = books.find(b => b.isbn === isbn);
  if (!book) {
    const err = new Error('Book not found'); err.status = 404; return next(err);
  }
  const { review } = req.body || {};
  if (typeof review !== 'string' || !review.trim()) {
    const err = new Error('review (string) required'); err.status = 400; return next(err);
  }
  const username = req.user.username;
  book.reviews ||= [];
  const existing = book.reviews.find(r => r.user === username);
  if (existing) existing.review = review;
  else book.reviews.push({ user: username, review });
  return res.json({ message: 'review saved', data: book.reviews });
}

// DELETE /auth/review/:isbn  (Task 9)
function deleteOwnReview(req, res, next) {
  const { isbn } = req.params;
  const book = books.find(b => b.isbn === isbn);
  if (!book) {
    const err = new Error('Book not found'); err.status = 404; return next(err);
  }
  const username = req.user.username;
  book.reviews = (book.reviews || []).filter(r => r.user !== username);
  return res.json({ message: 'review deleted (if existed)', data: book.reviews });
}

module.exports = { upsertReview, deleteOwnReview };
