const jwt = require('jsonwebtoken');

function authRequired(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) {
    const err = new Error('Authorization token required'); err.status = 401; return next(err);
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    req.user = decoded; // { sub, username, iat, exp }
    return next();
  } catch {
    const err = new Error('Invalid token'); err.status = 401; return next(err);
  }
}

module.exports = { authRequired };
