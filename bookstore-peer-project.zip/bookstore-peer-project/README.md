# Bookstore API (Tasks 1–14 Complete)

Minimal backend for the Coursera/IBM peer project with **books**, **users**, **JWT auth**, **reviews**, and an **Axios client** script.

## Features ↔ Tasks
**General users**
- (Task 1) `GET /books` — list all books
- (Task 2) `GET /books/isbn/:isbn` — get a book by ISBN
- (Task 3) `GET /books/author/:author` — search by author (substring, case-insensitive)
- (Task 4) `GET /books/title/:title` — search by title (substring, case-insensitive)
- (Task 5) `GET /books/review/:isbn` — get reviews for a book

**Users**
- (Task 6) `POST /users/register` — register a new user `{ username, password }`
- (Task 7) `POST /users/login` — login to get a JWT `{ token }`

**Registered (JWT)**
- (Task 8) `PUT /auth/review/:isbn` — add/modify your review `{ review }`
- (Task 9) `DELETE /auth/review/:isbn` — delete your own review

**Node.js + Axios Client**
- (Task 10) async/await: get all books
- (Task 11) Promises: search by ISBN
- (Task 12) search by Author
- (Task 13) search by Title

**Repo**
- (Task 14) Push this folder to GitHub and submit the link.

## Setup
```bash
npm install
cp .env.example .env   # Windows: copy .env.example .env
npm start              # runs at http://localhost:3000
```

## Sample Data
- Preloaded books (3 classic titles).
- Demo user gets auto-created on first run: `demo` / `password` (see store.js).

## Endpoints (cURL)
### Public
```bash
curl -s http://localhost:3000/books | jq
curl -s http://localhost:3000/books/isbn/9780132350884 | jq
curl -s http://localhost:3000/books/author/martin | jq
curl -s http://localhost:3000/books/title/code | jq
curl -s http://localhost:3000/books/review/9780132350884 | jq
```

### Register + Login (JWT)
```bash
curl -s -X POST http://localhost:3000/users/register   -H "Content-Type: application/json"   -d '{"username":"alice","password":"p@ssw0rd"}' | jq

curl -s -X POST http://localhost:3000/users/login   -H "Content-Type: application/json"   -d '{"username":"alice","password":"p@ssw0rd"}' | jq
# => { token: "..." }
```

### Authenticated Reviews
```bash
TOKEN=<paste token here>
curl -s -X PUT http://localhost:3000/auth/review/9780132350884   -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json"   -d '{"review":"Must-read for clean code practices!"}' | jq

curl -s -X DELETE http://localhost:3000/auth/review/9780132350884   -H "Authorization: Bearer $TOKEN" | jq
```

## Axios Client (Tasks 10–13)
```bash
npm run client
```
or
```bash
node client.js
```

## Notes
- In-memory storage only (simple review logic: upsert by username).
- For production, replace `JWT_SECRET` in `.env`.
- Provide **screenshots** of key endpoints, plus your GitHub repo link for Task 14.
