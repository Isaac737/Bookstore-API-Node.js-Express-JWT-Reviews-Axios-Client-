require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const cors = require('cors');

const bookRoutes = require('./src/routes/books');
const publicUserRoutes = require('./src/routes/publicUsers');
const authRoutes = require('./src/routes/authRoutes');
const { notFound, errorHandler } = require('./src/middleware/error');

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Health
app.get('/', (req, res) => {
  res.json({ status: 'ok', message: 'Bookstore API running' });
});

// Routes
app.use('/books', bookRoutes);              // Tasks 1-5
app.use('/users', publicUserRoutes);        // Tasks 6-7 (register/login)
app.use('/auth', authRoutes);               // Tasks 8-9 (protected review ops)

// 404 + error handler
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
