/**
 * Tasks 10–13: Node.js client using Axios
 * Task 10: Get all books – async/await
 * Task 11: Search by ISBN – Promises
 * Task 12: Search by Author – async/await
 * Task 13: Search by Title – async/await
 */
const axios = require('axios');

const BASE = process.env.BASE_URL || 'http://localhost:3000';

async function task10_getAllBooks() {
  const res = await axios.get(`${BASE}/books`);
  console.log('Task 10: All Books count =', res.data.data.length);
}

function task11_searchByISBN(isbn) {
  return axios.get(`${BASE}/books/isbn/${isbn}`)
    .then(res => {
      console.log('Task 11: Found by ISBN:', res.data.data.title);
    })
    .catch(err => {
      console.error('Task 11: Error', err.response ? err.response.data : err.message);
    });
}

async function task12_searchByAuthor(q) {
  const res = await axios.get(`${BASE}/books/author/${encodeURIComponent(q)}`);
  console.log(`Task 12: Author contains "${q}" =>`, res.data.data.map(b => b.title));
}

async function task13_searchByTitle(q) {
  const res = await axios.get(`${BASE}/books/title/${encodeURIComponent(q)}`);
  console.log(`Task 13: Title contains "${q}" =>`, res.data.data.map(b => b.title));
}

(async () => {
  await task10_getAllBooks();
  await task11_searchByISBN('9780132350884');
  await task12_searchByAuthor('martin');
  await task13_searchByTitle('code');
})();
